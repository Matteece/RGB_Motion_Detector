#include <msp430.h>
#include <stdint.h>

#define LOW 0
#define HIGH 1
#define low 0
#define high 1
#define DEVELOPMENT 0x5A80 // Stop the watchdog timer
#define ENABLE_PINS 0xFFFE // Required to use inputs and outputs
#define true 1
#define false 0

#define INPUT 0
#define INPUT_PULLUP 1
#define INPUT_PULLDOWN 2
#define OUTPUT 3

void setup() {
    WDTCTL = DEVELOPMENT; // Need for development mode
    PM5CTL0 = ENABLE_PINS; // Prepare pins for I/O usage
    // Timer B with counter length of 8-bit, sub-master clock, /1 divider, continuous mode, clear TBCLR, interrupt disabled
    TB0CTL = CNTL_3 | TBSSEL_2 | ID_0 | MC_2 | TBCLR;

    // Timer B CCTLn register configuration
    // set/reset
    // pins to use for RGB LED: P2.7(red), P2.6(green), P3.6(blue)
    TB0CCTL2 = OUTMOD_7;
    TB0CCTL5 = OUTMOD_7;
    TB0CCTL6 = OUTMOD_7;
    TB0CCR2 = 0;
    TB0CCR5 = 0;
    TB0CCR6 = 0;

    // Pins 2.7 and 2.6 here are being set up to send PWM signals
    P2SEL0 |= 0b11000000;
    P2SEL1 &= ~0b11000000;
    P2DIR |= 0b11000000;

    // Same thing here, pin 3.6 is being set up to send PWM signals
    P3SEL0 &= ~0b01000000;
    P3SEL1 |= 0b01000000;
    P3DIR |= 0b01000000;

    // Configure P3.3 for use with the echo pin on the ultrasonic range finder, this needs to be the input to the capture/compare register
    P3SEL0 &= ~0b00001000;
    P3SEL1 |= 0b00001000;
    P3DIR &= ~0b00001000;

    // Configure timer A1 for the pulseIn function
    TA1CTL = TASSEL_2 | ID__2 | MC_2 | TACLR;
}

void setupClock() {
    // Configure sub-master clock
    // Password for writing to clock system control registers
    CSCTL0 = CSKEY;

    // Select 4 MHz to be in compliance with the LCD.
    CSCTL1 = DCOFSEL_3;

    // Select the oscillating crystal clock because it's extremely stable.
    // We need to select the DCOCLK through the sub-master and master clocks.
    CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK;

    // Set the clock dividers.  In this case, /2 to be in compliance with the LCD.
    CSCTL3 = DIVA__1 | DIVS__2 | DIVM__1;

}

void pinMode(uint8_t port, uint8_t pin, uint8_t io) {
    // PxDIR is 0 for input
    // PxDIR is 1 for output
    // PxOUT is 0 for pull-down resistor
    // PxOUT is 1 for pull-up resistor
    // PxREN is 0 to disable resistor
    // PxREN is 1 to enable resistor

    uint8_t dir = 0;
    uint8_t ren = 0;
    uint8_t out = 0;

    // Set up variables for the registers
    switch(io) {
    case INPUT:
        dir = 0;
        ren = 0;
        out = 0;
        break;

    case INPUT_PULLUP:
        dir = 0;
        ren = 1;
        out = 1;
        break;

    case INPUT_PULLDOWN:
        dir = 0;
        ren = 1;
        out = 0;
        break;

    case OUTPUT:
        dir = 1;
        ren = 0;
        out = 0;
        break;
    }

    // Adjust variables so their values line up with the specified pin
    dir = dir << pin;
    ren = ren << pin;
    out = out << pin;

    // Mask used to clear the specified bit before modifying it
    uint8_t mask = ~(1 << pin);

    // Assign the variable values to the registers by first clearing the specified bit then using a bitwise OR to modify it.
    switch(port) {
    case 1:
        P1DIR = (P1DIR & mask) | dir;
        P1REN = (P1REN & mask) | ren;
        P1OUT = (P1OUT & mask) | out;
        break;

    case 2:
        P2DIR = (P2DIR & mask) | dir;
        P2REN = (P2REN & mask) | ren;
        P2OUT = (P2OUT & mask) | out;
        break;

    case 3:
        P3DIR = (P3DIR & mask) | dir;
        P3REN = (P3REN & mask) | ren;
        P3OUT = (P3OUT & mask) | out;
        break;

    case 4:
        P4DIR = (P4DIR & mask) | dir;
        P4REN = (P4REN & mask) | ren;
        P4OUT = (P4OUT & mask) | out;
        break;

    case 5:
        P5DIR = (P5DIR & mask) | dir;
        P5REN = (P5REN & mask) | ren;
        P5OUT = (P5OUT & mask) | out;
        break;

    case 6:
        P6DIR = (P6DIR & mask) | dir;
        P6REN = (P6REN & mask) | ren;
        P6OUT = (P6OUT & mask) | out;
        break;

    case 7:
        P7DIR = (P7DIR & mask) | dir;
        P7REN = (P7REN & mask) | ren;
        P7OUT = (P7OUT & mask) | out;
        break;

    case 8:
        P8DIR = (P8DIR & mask) | dir;
        P8REN = (P8REN & mask) | ren;
        P8OUT = (P8OUT & mask) | out;
        break;

    case 9:
        P9DIR = (P9DIR & mask) | dir;
        P9REN = (P9REN & mask) | ren;
        P9OUT = (P9OUT & mask) | out;
        break;

    case 10:
        P10DIR = (P10DIR & mask) | dir;
        P10REN = (P10REN & mask) | ren;
        P10OUT = (P10OUT & mask) | out;
        break;
    }
}

void digitalWrite(uint8_t port, uint8_t pin, uint8_t value) {
    // Create a mask that clears the specified bit (the pin)
    uint8_t mask = ~(1 << pin);

    // Assign the specified HIGH or LOW value to the appropriate bit by shifting the value over pin many times.
    switch(port) {
        case 1:
            P1OUT = (P1OUT & mask) | (value << pin);
            break;

        case 2:
            P2OUT = (P2OUT & mask) | (value << pin);
            break;

        case 3:
            P3OUT = (P3OUT & mask) | (value << pin);
            break;

        case 4:
            P4OUT = (P4OUT & mask) | (value << pin);
            break;

        case 5:
            P5OUT = (P5OUT & mask) | (value << pin);
            break;

        case 6:
            P6OUT = (P6OUT & mask) | (value << pin);
            break;

        case 7:
            P7OUT = (P7OUT & mask) | (value << pin);
            break;

        case 8:
            P8OUT = (P8OUT & mask) | (value << pin);
            break;

        case 9:
            P9OUT = (P9OUT & mask) | (value << pin);
            break;

        case 10:
            P10OUT = (P10OUT & mask) | (value << pin);
            break;
        }
}

uint8_t digitalRead(uint8_t port, uint8_t pin) {
    uint8_t mask = (1 << pin);

    // Return either HIGH or LOW by clearing every bit except the specified one, and shifting it over all the way to the right.
    switch(port) {
        case 1:
            return (P1IN & mask) >> pin;

        case 2:
            return (P2IN & mask) >> pin;

        case 3:
            return (P3IN & mask) >> pin;

        case 4:
            return (P4IN & mask) >> pin;

        case 5:
            return (P5IN & mask) >> pin;

        case 6:
            return (P6IN & mask) >> pin;

        case 7:
            return (P7IN & mask) >> pin;

        case 8:
            return (P8IN & mask) >> pin;

        case 9:
            return (P9IN & mask) >> pin;

        case 10:
            return (P10IN & mask) >> pin;
        }
    return 0;
}

// Delays the function by microseconds
void delayMicroseconds(unsigned int input) {
    // Configure capture/compare register
    TA0CCR0 = input - 1;

    // Configure timer 0 to use the sub-master clock, input divider /2, up mode, enable timer clear
    TA0CTL = TASSEL_2 | ID__2 | MC_1 | TACLR;

    // Delay the function
    while (!(TA0CCTL0 & CCIFG));

}

// Since this is getting modified by an interrupt, it must be declared volatile.  This makes it reload from memory instead of using a value in a register
volatile unsigned int timeElapsed = 0;

#pragma vector = TIMER0_A0_VECTOR
__interrupt void increaseTime(void) {
    timeElapsed++;
}

// Delays the function by milliseconds
void delay(unsigned int input) {
    TA0CCR0 = 999;

    // Enable interrupt
    TA0CCTL0 = CCIE;

    // Configure timer 0 to use the sub-master clock, input divider /2, up mode, enable timer clear
    TA0CTL = TASSEL_2 | ID__2 | MC_1 | TACLR;

    // Delay the function
    while (timeElapsed < input);
    // Clear interrupt once done
    TA0CCTL0 = 0;
    timeElapsed = 0;
}


void analogWrite(uint8_t port, uint8_t pin, uint8_t value) {
    // pins to use for RGB LED: P2.7(red), P2.6(green), P3.6(blue)
    if (port == 3 && pin == 6) {
        TB0CCR2 = value; // P3.6
    } else if (port == 2 && pin == 6) {
        TB0CCR5 = value; // P2.6
    } else if (port == 2 && pin == 7) {
        TB0CCR6 = value; // P2.7
    }
}


uint16_t pulseIn() {
    TA1CTL |= TACLR;
    TA1CCTL1 = CM_1 | CAP;

    // spin until interrupt pending
    while(!(TA1CCTL1 & CCIFG));
    uint16_t captured = TA1CCR1;

    // Capture on falling edge
    TA1CCTL1 = CM_2 | CAP;

    // spin again
    while(!(TA1CCTL1 & CCIFG));
    uint16_t captured1 = TA1CCR1;

    return captured1 - captured;
}


int ping_cm(int TRIGGER_PORT, int TRIGGER_PIN){
    int dist = 0;
    long duration;
    digitalWrite(TRIGGER_PORT, TRIGGER_PIN, LOW);
    delayMicroseconds(2);
    // Sets the trigPin on HIGH state for 10 micro seconds
    digitalWrite(TRIGGER_PORT, TRIGGER_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIGGER_PORT, TRIGGER_PIN, LOW);
    duration = pulseIn(); // Reads the echoPin, returns the sound wave travel time in microseconds
    dist = duration*0.034/2;
    return dist;
}
