#include <helpful_functions.h>
#define DEVIATE_DISTANCE 5
int oldDist = 0;

// Function for setting the color of the RGB LED
void setColor(int red, int green, int blue) {
  analogWrite(2, 7, red);
  analogWrite(2, 6, green);
  analogWrite(3, 6, blue);
}

uint8_t deviate(int i) {
    // This function compares the passed in distance with the old distance, which is a global variable, and if it's different by 5 cm in either direction it returns true,
    // which then breaks the loop in wait(), and allows the for loop calling it to cycle the RGB LED through its colors.
    delay(50);
    if (i >= (oldDist + DEVIATE_DISTANCE) || (i <= oldDist - DEVIATE_DISTANCE)) {
        return true;
    }
        return false;
}

void wait(int dist) {
    while(true) {
        oldDist = dist;
        dist = ping_cm(8, 5);
        // What this loop is doing is constantly pinging the sensor, waiting for a deviation of 5 cm in either direction.
        if (deviate(dist)) {
          break;
        }
    }
}

void colorChange(int dist) {
    // This function uses for loops to cycle the RGB LED through its color spectrum, or at least part of it.  For every instance of the loop, the wait() function is called to setup the chain
    // Up and down blue
    // Red to pink
    for (int i = 0; i <= 255; i++) {
        wait(dist);
        setColor(255, 0, i);
    }
    int g = 0;
    // start transition to white then green
    for (int i = 255; i > -1; i--) {
        wait(dist);
        setColor(255, g, i);
        g++;
    }
    // this is where the blip happens
    // Update: the if statement inside this loop seems to have fixed it
    // Green
    for (int i = 0; i <= 255; i++) {
        wait(dist);
        if (i < 1) {
            setColor(255, 255, 0);
        } else {
            setColor(g, 255, 0);
        }
        g--;
    }
    // Change to cyan and then blue
    for (int i = 0; i <= 255; i++) {
        wait(dist);
        setColor(0, 255, i);
    }
    // change to pure blue
    for (int i = 255; i > -1; i--) {
        wait(dist);
        setColor(0, i, 255);
    }
    // start mixing purple
    for (int i = 0; i <= 255; i++) {
        wait(dist);
        setColor(i, 0, 255);
    }
    // change back to red
    for (int i = 255; i > -1; i--) {
        wait(dist);
        setColor(255, 0, i);
    }
}

/**
 * main.c
 */
int main(void) {
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	setup();
	setupClock();
	_enable_interrupts();


	// pinMode(3, 3, OUTPUT); // echo pin
	pinMode(8, 5, OUTPUT); // trigger pin
	



// pins to use for RGB LED: P2.7(red), P2.6(green), P3.6(blue)

	while (1) {
	    delay(50); // Wait 50ms between pings (about 20 pings/sec). 29ms should be the shortest delay between pings.
	    int dist = ping_cm(8, 5); // ping the distance
	    colorChange(dist);
	}
}
